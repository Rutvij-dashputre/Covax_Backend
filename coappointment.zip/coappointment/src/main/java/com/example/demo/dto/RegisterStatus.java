package com.example.demo.dto;


public class RegisterStatus extends Status{
	

	private int registeredCustomerNo;

	public int getRegisteredCustomerNo() {
		return registeredCustomerNo;
	}

	public void setRegisteredCustomerNo(int registeredCustomerNo) {
		this.registeredCustomerNo = registeredCustomerNo;
	}
	
}
